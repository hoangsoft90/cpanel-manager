#current project directory
$ScriptRoot = Split-Path $MyInvocation.MyCommand.Path

."$ScriptRoot\functions.ps1"
#."$ScriptRoot\libs\Http-RestCommunicate.ps1"

echo "Chu y: Cau hoi Yes/No bat (Caps Lock) dien ky tu Y/N chinh xac, khong duoc viet thuong."
#---------------------------------------------------------------------------------------------------------------------
###########
#input
###########
$acc_id = '24'
$wp_subdomain = ''
$root_acc = ''
#db info
$db_id = '2'

#$_up_wpcore = questionYesNo("Upload Wordpress Core ?")
$_up_theme = "1"
$_up_hwplugins = "1"
$new_wp_ver = "1"


## All variables will need changing to suit your environment
connectDB

# get acc
$sql='SELECT accts.id,accts.cpanel_user,accts.cpanel_pass,accts.cpanel_host,accts.cpanel_domain,accts.root
    ftp_user,ftp_pass,ftp.path,dbuser.db,dbuser,dbpass,ssh_key,ssh_key_pass
 FROM `cpanel-accts` as accts 
    left join `cpanel-ftp` as ftp on accts.id=ftp.cpid
    left join `cpanel-tokens` as tokens on accts.id=tokens.cpid 
    left join `cpanel-dbusers` as dbuser on accts.id=dbuser.cpid 
    where accts.id={0}  and (path is NULL or path in ("","/","public_html","public_html\\","/public_html","/public_html/")) limit 1' -f ($acc_id)
    
$sql    
$acc = Get-SqlDataTable ($sql)
if($acc.length -eq 0) {
    Exit
}
## get data from db
$server_ip = $acc.cpanel_host
$user = $acc.cpanel_user
#cpanel pass
$pass = curl -s ("http://localhost/cpanel/ajax.php?do=decpass&str={0}" -f ($acc.cpanel_pass))
$acc.cpanel_pass=$pass   #update decoded pass
#db pass
$acc.dbpass = curl -s ("http://localhost/cpanel/ajax.php?do=decpass&str={0}" -f ($acc.dbpass))

$acc

$app=openAccViewer $acc "$ScriptRoot/"
#### --------------------------------upload wp core------------------------------------------
$app
Start-Sleep -s 2
#$app=ConvertTo-Json $app

Stop-Process -id $app.Id