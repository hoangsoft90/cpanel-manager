#current project directory
$ScriptRoot = Split-Path $MyInvocation.MyCommand.Path

function questionYesNo($msg,$def=""){  #($msg, $def)
    $message  = 'Hoangweb'
    $question = $msg

    $choices = New-Object Collections.ObjectModel.Collection[Management.Automation.Host.ChoiceDescription]
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&Yes'))
    $choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&No'))

echo "($def)"
    if(Is-Numeric $def -and -not [string]::IsNullOrEmpty($def)) {
        $decision=$def
    }
    else{
        $decision = $Host.UI.PromptForChoice($message, $question, $choices, 1)  #[int]$def
    }
    return $decision
}
function Is-Numeric ($Value) {
    return $Value -match "^[\d\.]+$"
}
Function IIf($If, $Right, $Wrong) {If ($If) {$Right} Else {$Wrong}}

$ftp=get-content "$ScriptRoot\ftp.txt"#|out-string
$ftp_info = @{}

$ftp | foreach {
   $items = $_.split(":")
   #if ($items[0] -eq "ProductA"){Echo $items[1]}
   $ftp_info[$items[0]]=$items[1]
}
$t = (IIf ($ftp_info["upload_wpcore"] -eq "Y") 0 1)
$t