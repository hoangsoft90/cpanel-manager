__author__ = 'Hoang'
#!/usr/bin/python
import sys
import PyQt4
from PyQt4 import QtGui

class mainWidget(QtGui.QWidget):

    def __init__(self):
        super(mainWidget, self).__init__()

        self.initUI()

    def initUI(self):
        vbox = QtGui.QVBoxLayout()
        vbox.addStretch(1)

        #get external param

        txt="".join(sys.argv[1:])
        txt="\n".join(txt.split('<<|>>'))

        longTxt = QtGui.QTextBrowser( )
        longTxt.setText(txt)
        vbox.addWidget(longTxt)

        hbox = QtGui.QHBoxLayout()
        hbox.addStretch(1)
        vbox.addLayout(hbox)

        btn_ok=QtGui.QPushButton()
        btn_ok.setText("Ok")
        btn_ok.clicked.connect(PyQt4.QtCore.QCoreApplication.instance().quit)
        hbox.addWidget(btn_ok)

        self.setLayout(vbox)
        self.setGeometry(400, 400, 350, 350)
        self.setWindowTitle('Hoangweb')
        self.show()

def main():
    app = QtGui.QApplication(sys.argv)
    t=mainWidget()    #note you must assigning instance to variable, otherwise gui not show
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
