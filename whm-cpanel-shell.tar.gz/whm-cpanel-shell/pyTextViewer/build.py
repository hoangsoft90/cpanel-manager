from distutils.core import setup
import py2exe,os
import glob

setup(
    #console=['main.py'],
    name="simple text editor write by Hoangweb",
    version="1.0",
    description="Phan mem hoc truc tuyen.",
    author="Hoangweb.COM",
    options={
                "py2exe":{
                    "dll_excludes": ["MSVCP90.dll", "HID.DLL", "w9xpopen.exe"],
                    #   "unbuffered": True,
                    #"bundle_files":1,
                    #    "optimize": 2,
                    #'compressed': True,
                    'includes':['sip',"PyQt4"],
                        #"excludes": ["email"]
                }
        },
    windows = [{
        'script': 'main.py'
        }]
)