# install & active the list of plugins
# example: ./hw-config-plugin.sh "/path/to/wordpress"
path=$1

#
# first to active my plugin for import/export
wp plugin install https://dl.dropboxusercontent.com/u/16994321/hoangweb/wp-plugins/hw-cli-plugins-settings.zip  --url="$path"
wp plugin activate hw-cli-plugins-settings  --url="$path"
exit;
#yoast seo
wp plugin install wordpress-seo --activate  --url="$path"
wp hw-wpseo import_settings  --url="$path"

# cache
wp plugin install w3-total-cache --activate  --url="$path"
wp hw-w3cache import_settings  --url="$path"

wp plugin install wordfence --activate  --url="$path"
wp plugin install captcha --activate  --url="$path"
wp plugin install google-authenticator --activate  --url="$path"

echo "===================================================\n"
echo "Hoan tat !"
echo "===================================================\n"