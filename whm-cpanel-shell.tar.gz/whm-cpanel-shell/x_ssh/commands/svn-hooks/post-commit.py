#!/bin/env python
" Example Subversion pre-commit hook. "

from sys import argv, stderr, exit
import os,sys,re
import commands
import subprocess
#import pyfig
repo = argv[1]
transaction = argv[2]

def command_output(cmd):
  " Capture a command's standard output. "
  import subprocess
  process=subprocess.Popen(
      cmd.split(), stdout=subprocess.PIPE,shell=False,stderr=subprocess.PIPE)#.communicate()[0]
  output, err  = process.communicate()
  return output if output else err

def files_delete_queue(look_cmd):
	"delete files in queue in pre-commit hook"
	def filename(line):
		return line[4:]
	def deleled(line):
		return line and line[0] in ("D")
	return [
		filename(line)
		for line in command_output(look_cmd % "changed").split("\n")
		if deleled(line)]
	
def files_changed(look_cmd):
  """ List the files added or updated by this transaction.

"svnlook changed" gives output like:
  U   trunk/file1.cpp
  A   trunk/file2.cpp
  """
  def filename(line):
      return line[4:]
  def added_or_updated(line):
      return line and line[0] in ("A", "U")
  return [
      filename(line)
      for line in command_output(look_cmd % "changed").split("\n")
      if added_or_updated(line)]

def file_contents(filename, look_cmd):
  " Return a file's contents for this transaction. "
  return command_output(
     "%s %s" % (look_cmd % "cat", filename))

def allow_ext(fname):
	import os
	#allow extension
	exts=".txt .html .htm .php .PHP3 .PHP4 .PHP5 .css .jpg .jpeg .png .gif .woff2 .ico .asp .aspx .CSHTML .DHTML .DWT .FMP .HTACCESS .HTX .JHTML .JS .JSF .JSON .JSP .MAP .LESS .MOZ .scss .eot .woff .ttf .otf .svg .swf .xml .db .db-journal"
	exts=exts.lower().strip()+" "+exts.upper().strip()
	
	#if is directory
	if(re.match(".+\/$", fname)):
		return True
	return os.path.splitext(fname)[1] in exts.split()

def write_log(repos,text):
	file = open(repos+ "/hooks/log.txt", "a+")
	file.write(str(text)+"\n")
	file.close()
	
def main():
  usage = """usage: %prog REPOS TXN

Run pre-commit options on a repository transaction."""
  from optparse import OptionParser
  parser = OptionParser(usage=usage)
  parser.add_option("-r", "--revision",
                    help="Test mode. TXN actually refers to a revision.",
                    action="store_true", default=False)
  errors=0
  try:
	#get params
	(opts, (repos, txn_or_rvn)) = parser.parse_args()
	look_opt = ("--revision","--transaction")[opts.revision]
	look_cmd = "svnlook %s %s %s %s" % (
          "%s", repos, look_opt, txn_or_rvn)
	
	hoangapp_path="/home/hangwebvnn/hoangapp"
	## Execute the svnlook command to get the author of the commit if any.
	author=command_output(look_cmd % "author")
	
	tu = (repos,txn_or_rvn,author)
	# send mail to user when first commit was made
	os.system("python "+hoangapp_path+"/hw-mailer.py --only_first_commit=1 --body='"+repos+" "+author+"' --svn_user='"+author+"' --type='svn_theme_working_copy'")
	
	# update theme status set to 1 tell hoangweb.vn this repository updated
	os.system("python " +hoangapp_path+"/hw-wp-update-theme-status.py --svn_user='"+author+"' --theme_path='"+repos+"' --theme_status='"+repos+"'")
	
	# looking for readme.txt for new revision
	for ff in files_changed(look_cmd):
		"sys.stderr.write(ff)"
		if re.search("(\s+)?readme\.txt$", ff):
			write_log(repos, "detect change readme==>"+ff)
			# add/update post on hoangweb.vn for this theme
			#execfile(hoangapp_path+"/hw-wp-add-theme.py --svn_user='{2}' --theme_path='{0}'".format(*tu))
			os.system("python " + hoangapp_path+"/hw-wp-add-theme.py --svn_user='{2}' --theme_path='{0}'".format(*tu))
			break
	
	#sys.exit(2) 
  except Exception as inst:
	parser.print_help()
	write_log(repos, inst)
	errors += 1
  return errors

if __name__ == "__main__":
  import sys
  r=main()
  sys.stderr.write(str(r))
  sys.exit(r)