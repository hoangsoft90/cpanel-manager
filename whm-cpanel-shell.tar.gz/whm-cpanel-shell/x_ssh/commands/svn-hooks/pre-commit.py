#!/bin/env python
" Example Subversion pre-commit hook. "

from sys import argv, stderr, exit
import os,sys,re
import commands
#import pyfig
repo = argv[1]
transaction = argv[2]

def command_output(cmd):
  " Capture a command's standard output. "
  import subprocess
  process=subprocess.Popen(
      cmd.split(), stdout=subprocess.PIPE,shell=False,stderr=subprocess.PIPE)#.communicate()[0]
  output, err  = process.communicate()
  return output if output else err

def files_delete_queue(look_cmd):
	"delete files in queue in pre-commit hook"
	def filename(line):
		return line[4:]
	def deleled(line):
		return line and line[0] in ("D")
	return [
		filename(line)
		for line in command_output(look_cmd % "changed").split("\n")
		if deleled(line)]
	
def files_changed(look_cmd):
  """ List the files added or updated by this transaction.

"svnlook changed" gives output like:
  U   trunk/file1.cpp
  A   trunk/file2.cpp
  """
  def filename(line):
      return line[4:]
  def added_or_updated(line):
      return line and line[0] in ("A", "U","R")
  return [
      filename(line)
      for line in command_output(look_cmd % "changed").split("\n")
      if added_or_updated(line)]

def file_contents(filename, look_cmd):
  " Return a file's contents for this transaction. "
  return command_output(
     "%s %s" % (look_cmd % "cat", filename))

def allow_ext(fname):
	import os
	#allow extension
	exts=".txt .html .htm .php .PHP3 .PHP4 .PHP5 .css .jpg .jpeg .png .gif .woff2 .ico .asp .aspx .CSHTML .DHTML .DWT .FMP .HTACCESS .HTX .JHTML .JS .JSF .JSON .JSP .MAP .LESS .MOZ .scss .eot .woff .ttf .otf .svg .swf .xml .db .db-journal"
	exts=exts.lower().strip()+" "+exts.upper().strip()
	
	#if is directory
	if(re.match(".+\/$", fname)):
		return True
	return os.path.splitext(fname)[1] in exts.split()

def write_log(repos,text):
	file = open(repos+ "/hooks/log.txt", "a+")
	file.write(str(text)+"\n")
	file.close()
	
def main():
  usage = """usage: %prog REPOS TXN

Run pre-commit options on a repository transaction."""
  from optparse import OptionParser
  parser = OptionParser(usage=usage)
  parser.add_option("-r", "--revision",
                    help="Test mode. TXN actually refers to a revision.",
                    action="store_true", default=False)
  errors = 0
  found_readme=0
  found_screenshot1=0
  repos=""
  try:
	(opts, (repos, txn_or_rvn)) = parser.parse_args()
	look_opt = ("--transaction", "--revision")[opts.revision]
	look_cmd = "svnlook %s %s %s %s" % (
          "%s", repos, look_opt, txn_or_rvn)
		  
	  #print "svnlook changed -t " + transaction + " " + repo
	
	"""
	check readme.txt contents
	"""
	c=command_output("svn info file://"+repo+"/readme.txt")
	if c and not "A problem occurred" in c:
		found_readme=1
		if not file_contents("readme.txt",look_cmd).strip():
			sys.stderr.write("Hoangweb-Error: File readme.txt khong co noi dung.\n")
			errors+=1
		
	"""
	check screenshot-1.jpg for exists
	"""
	c=command_output("svn info file://"+repo+"/screenshot-1.jpg")
	found_screenshot1=(1 if c and not "A problem occurred" in c else 0)
	
	"check for readme.txt,screenshot-1.jpg this file need to be present in repository"
	changed_files=[]	#gather change files
	for ff in files_changed(look_cmd):
		if not allow_ext(ff):
			sys.stderr.write("Hoangweb-Error: Dinh dang file khong cho phep: "+str(ff)+"\n")
			errors+=1
			break
		
		#remind file to list
		changed_files.append(ff)
		#sys.stderr.write(ff)
		if re.search("(\s+)?readme\.(txt|TXT)$", ff):
			found_readme=1
		if re.search("(\s+)?screenshot-1\.(jpg|JPG)$", ff):
			found_screenshot1=1
			break
	
	#detect remove readme.txt
	if files_delete_queue(look_cmd):
		for ff in files_delete_queue(look_cmd):
			if re.search("(\s+)?readme\.(txt|TXT)$|(\s+)?screenshot-1\.(jpg|JPG)$", ff) and not ff in changed_files:
				sys.stderr.write("Hoangweb-Error: Khong duoc xoa readme.txt hoac screenshot-1.jpg\n");
				errors+=1
				break;
			
	if not found_readme:
		sys.stderr.write("Hoangweb-Error: Khong tim thay file readme.txt\n")
		errors+=1
	if not found_screenshot1:
		sys.stderr.write("Hoangweb-Error: Khong tim thay file screenshot-1.jpg\n")
		errors+=1
	#sys.exit(2)	
  except Exception as inst:
	write_log(repos,inst)
	parser.print_help()
	errors+=1
  return errors

if __name__ == "__main__":
  import sys
  r=main()
  print r
  sys.exit(r)