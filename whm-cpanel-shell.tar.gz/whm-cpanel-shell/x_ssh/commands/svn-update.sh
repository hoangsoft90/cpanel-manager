echo '[Update SVN server!]'
#sudo su
sudo -u root -H sh -c 'cd ~;pwd;echo "Update vhost";/scripts/ensure_vhost_includes --all-users;read -n1 -r -p "Press any key to continue..." key'
#read -n1 -r -p 'Press any key to continue...' key