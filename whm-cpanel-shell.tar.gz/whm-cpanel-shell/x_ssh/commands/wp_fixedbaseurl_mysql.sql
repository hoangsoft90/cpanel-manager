update wp_options set option_value=REPLACE(option_value,"/wpmultisite","/");
update wp_posts set post_content=REPLACE(post_content,"/wpmultisite","/");
update wp_posts set guid=REPLACE(guid,"/wpmultisite","/");
update wp_postmeta set meta_value=REPLACE(meta_value,"/wpmultisite","/");
