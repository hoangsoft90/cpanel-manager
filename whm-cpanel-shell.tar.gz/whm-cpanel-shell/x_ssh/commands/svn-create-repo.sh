echo 'Create repository [mau-web-bang-hang]!'
#sudo su
sudo -u hangwebvnn -H sh -c 'cd ~;pwd;mkdir public_svn;echo "Creating themes dir";mkdir public_svn/themes;cd public_svn/themes;[ -d mau-web-bang-hang ] && read -p "mau-web-bang-hang already exists, override (y/n) ?" yn && [ "$yn" == "n" ] && (echo "exit !";exit) || (echo "Creating..repository themes/mau-web-bang-hang folder.";svnadmin create --fs-type fsfs mau-web-bang-hang;chgrp hangwebvnn mau-web-bang-hang;chmod o+rx mau-web-bang-hang;cd mau-web-bang-hang;chgrp -R hangwebvnn conf db format hooks locks README.txt dav;chmod g-w conf hooks;chgrp hangwebvnn conf/svnserve.conf conf/authz conf/passwd;chmod o+r conf/svnserve.conf;chmod g-w conf/authz conf/passwd;chgrp hangwebvnn hooks/*;[ -f /home/hangwebvnn/hoangapp/svn_hooks/pre-commit ] && (cp /home/hangwebvnn/hoangapp/svn_hooks/pre-commit /home/hangwebvnn/public_svn/themes/mau-web-bang-hang/hooks/pre-commit;) || echo "Khong tim thay hoangapp/../pre-commit";[ -f /home/hangwebvnn/hoangapp/svn_hooks/post-commit ] && cp /home/hangwebvnn/hoangapp/svn_hooks/post-commit /home/hangwebvnn/public_svn/themes/mau-web-bang-hang/hooks/post-commit || echo "Khong tim thay hoangapp/../post-commit";cd ~;chmod 775 -R public_svn/themes/mau-web-bang-hang;);cd ~;read -p "Want to update pass for user [thao92]? (y/n) ?" yn && [ "$yn" == "n" -a -f svn_users/thao92.svn.htpasswd ] && (echo "Sory !Created user pass before.";) || (echo "Creating ~svn_users folder to hold users credentials.";mkdir svn_users;cd svn_users;echo "Enter user pass [thao92] for your repository ?";hw_mysqluser="hangwebv_vms";hw_mysqlpsw="7g~d+z8rZMWl";hw_mysqldatabase="hangwebv_esvn";hw_svnpass_query="select svn_pass from svn_wp_users where svn_user=\"thao92\" limit 1";svn_enpass=$(mysql -u${hw_mysqluser} -p${hw_mysqlpsw} ${hw_mysqldatabase} -e "${hw_svnpass_query}");echo "My enpass:$svn_enpass";svn_depass=$(curl -s -d "str=$svn_enpass" "http://hoangweb.vn/ajax.php?do=dec_svn_pass");echo "My pass: $svn_depass"; /usr/local/apache/bin/htpasswd -bc ./thao92.svn.htpasswd thao92 $svn_depass;echo "saving user pass..to db");exit;'
sudo -u root -H sh -c 'cd ~;pwd;echo "chmod 755 for themes/mau-web-bang-hang folder.";chmod 775 -R /home/hangwebvnn/public_svn/themes/mau-web-bang-hang;chown -R hangwebvnn:nobody /home/hangwebvnn/public_svn/themes/mau-web-bang-hang;echo "Update vhost";/scripts/ensure_vhost_includes --all-users;'
#send mail to user about repository
read -p "Want to send mail to user [thao92] about this repository? (y/n) ?" yn && [ "$yn" == "y" ] && (python /home/hangwebvnn/hoangapp/hw-mailer_template.py --body="sdfsdg" --tpl="create_svn_repository.tpl" --svn_user="thao92" --type="alert_new_repo" --repository="mau-web-bang-hang") || (echo "No send mail about this repository.");
##...create post-commit by copying from local to server using terminal
#convert to unix format
#dos2unix post-commit

# It needs to be executable
#chmod u+x post-commit
#chmod 775 post-commit;
    
#modify pre-commit hook
    #cp /home/hangwebvnn/public_svn/themes/mau-web-bang-hang/hooks/pre-commit.tmpl /home/hangwebvnn/public_svn/themes/mau-web-bang-hang/hooks/pre-commit
##...create pre-commit by copying from local to server using terminal
#convert to unix format
#dos2unix pre-commit

# It needs to be executable
#chmod u+x pre-commit
#chmod 775 pre-commit;
    