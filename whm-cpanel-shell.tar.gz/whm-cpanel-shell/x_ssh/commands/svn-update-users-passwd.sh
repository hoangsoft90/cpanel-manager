echo 'Update all svn users pass !'
sudo -u root -H sh -c 'cd ~;pwd;/usr/local/apache/bin/htpasswd -bc ./hoang2.svn.htpasswd hoang2 $svn_depass;'
    