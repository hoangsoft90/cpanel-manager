param([string]$foo = "foo", [string]$bar = "bar")
$foo