param([string]$acc_id = "",[string]$file="")
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

##----- get account info
$acc=get_cpanel_info $acc_id

#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc

#open acc viewer
$accViewer=openAccViewer $acc

#------------------------------------------------------
$ssh_key="$PSScriptRoot\ssh-keys/{0}-sshkey.ppk" -f ($acc.cpanel_user)
$url = ("/c {0}/commands/download-file.bat {1} {2} {3} {4}" -f $PSScriptRoot,$acc.cpanel_host, $acc.cpanel_user,$acc.cpanel_pass,$file,"$PSScriptRoot\tmp")
$url
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}