param([string]$acc_id = "" )
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

##----- get account info
$acc=get_cpanel_info $acc_id
$user = $acc.cpanel_user
#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
$accViewer=openAccViewer $acc

#------------------------------------------------------
## modify create-cpbackup.txt
$cmds= "/scripts/restorepkg --force --skipaccount {0}" -f ($acc.cpanel_user)

$cmds ="$($cmds)","","read -n1 -r -p 'Press any key to continue...' key"
$cmds|set-content "commands/cpbackup-restore.txt" -Encoding Ascii

##run create-cpbackup.bat
$url = ("/c {0}/commands/cpbackup-restore.bat {1} {2} {3}" -f $PSScriptRoot,$acc.cpanel_host, "root","u2Z6qKJAKgQgGdc")
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}