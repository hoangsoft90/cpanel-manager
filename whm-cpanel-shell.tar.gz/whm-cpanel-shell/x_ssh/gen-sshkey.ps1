#Set-ExecutionPolicy RemoteSigned
#send params to the script
param([string]$acc_id = "", [string]$bar = "bar")

$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"


if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}

$generate_sshkey = questionYesNo "Generate ssh key"
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

####### get acc
$acc=get_cpanel_info $acc_id
$server_ip = $acc.cpanel_host
$user = $acc.cpanel_user

$acc
#open acc viewer
$accViewer=openAccViewer $acc

#============================Start=====================================
# generate ssh key for account
if ($generate_sshkey -eq 0) {
    $url="/c echo 'generate ssh key for {0}...and sleep 5s'&&curl `"{1}?do=generate_sshkey&auth=1`" -d `"acc={2}`" " -f $acc.cpanel_user,$cpanel_ajax,$acc_id
    $url
    $procs =Start-process "cmd.exe" $url -wait
    Start-Sleep -s 5
}
#download all ssh keys on cpanel server
$url = ("/c {0}/commands/download-ssh-keys.bat {1} {2} {3} {4}" -f $PSScriptRoot,$user, $acc.cpanel_pass,$server_ip,$PSScriptRoot)
$url        
Start-Process "cmd.exe"  $url -wait
echo "downloaded all ssh keys file from the server in following path /ssh-keys folder."

#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}