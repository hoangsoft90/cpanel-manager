<#=====================================================================================
Create repository on my SVN subversion http://svn.hoangweb.vn/
======================================================================================#>
param([string]$acc_id = "", [string]$root_user='root', [string]$root_pass="",[string]$repo_name="",[int]$autopass)
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

## get account info
$acc=get_cpanel_info $acc_id
$server_ip = $acc.cpanel_host
$user = $acc.cpanel_user
#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
#$accViewer=openAccViewer $acc

$url = ("/c {0}/commands/svn-create-repo.bat {1} {2} {3} {4} {5} {6} {7}" -f $PSScriptRoot,$server_ip, $root_user,$root_pass,
        $acc.cpanel_user, "$PSScriptRoot\ssh-keys/authorized_keys", $repo_name, $autopass)
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}