param([string]$acc_id = "", [string]$root_user='root', [string]$root_pass="",[string]$command_txt="",[string]$ssh_batch="ssh-root.bat",[string]$account="")
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

## get account info
$acc=get_cpanel_info $acc_id
$server_ip = $acc.cpanel_host
#$user = $acc.cpanel_user
if([string]::IsNullOrEmpty($account)){
    $account= $acc.cpanel_user
}
#valid
if(-not ($acc -contains "ssh_key_pass") -or [string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
$accViewer=openAccViewer $acc

<#
## run ssh-root.bat with command text passed in
$command_txt: stored in commands/ folder
#>
$url = ("/c {0}/commands/$ssh_batch {1} {2} {3} {4} {5}" -f $PSScriptRoot,$server_ip, $root_user,$root_pass, $command_txt, $account)
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}