param([string]$acc_id = "", [string]$command_txt="")
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

## get account info
$acc=get_cpanel_info $acc_id
$server_ip = $acc.cpanel_host
$user = $acc.cpanel_user
#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
$accViewer=openAccViewer $acc

<#
## run ssh.bat with command text passed in
$command_txt: stored in commands/ folder
#>
$url = ("/c {0}/commands/ssh.bat {1} {2} {3} {4} {5}" -f $PSScriptRoot,$server_ip, $user,$acc.ssh_key_pass,"$PSScriptRoot\ssh-keys/$user-sshkey.ppk",$command_txt)
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}