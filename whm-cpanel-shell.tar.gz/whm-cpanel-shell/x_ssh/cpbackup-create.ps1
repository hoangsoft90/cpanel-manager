param([string]$acc_id = "", [string]$cloneacc='')
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

##----- get account info
$acc=get_cpanel_info $acc_id
$user = $acc.cpanel_user
#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
$accViewer=openAccViewer $acc

#------------------------------------------------------
## modify create-cpbackup.txt
$cmds= "/scripts/pkgacct {0}" -f ($acc.cpanel_user)
if([string]::IsNullOrEmpty($cloneacc)) {
    $cp_linux=""
}
else {    
    $cp_linux = ("cp /home/cpmove-{0}.tar.gz /home/cpmove-{1}.tar.gz" -f $acc.cpanel_user,$cloneacc),"echo 'Cloned backup file to other account'"
}
$cmds ="$($cmds)",$cp_linux,"read -n1 -r -p 'Press any key to continue...' key"
$cmds|set-content "commands/cpbackup-create.txt" -Encoding Ascii

##run create-cpbackup.bat
$url = ("/c {0}/commands/cpbackup-create.bat {1} {2} {3}" -f $PSScriptRoot,$acc.cpanel_host, "root","u2Z6qKJAKgQgGdc")
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}