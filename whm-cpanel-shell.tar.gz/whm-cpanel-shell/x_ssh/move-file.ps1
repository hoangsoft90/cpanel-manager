param([string]$acc_id = "",[string]$file="", [string]$moving_acc="", [string]$rename_userfile='0')
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
if([string]::IsNullOrEmpty($moving_acc)) {
    $moving_acc = Read-host "Enter account id you want to transfer ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

##----- get account info
$acc=get_cpanel_info $acc_id

#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
##----- get target account info
$target_acc= get_cpanel_info $moving_acc


#open acc viewer
$accViewer=openAccViewer $acc
$target_accViewer=openAccViewer $target_acc   #open viewer for other server

#for backup file contain username
if($rename_userfile -eq '1') {
    $new_file=[System.IO.Path]::GetFileName($file) -replace $acc.cpanel_user,$target_acc.cpanel_user
    
}else{
    $new_file=[System.IO.Path]::GetFileName($file)
}


# modify  movefile-to-server.txt
$cmds= "pscp '{0}' '{1}@{2}':./$new_file" -f ($file,$target_acc.cpanel_user, $target_acc.cpanel_host)
#$cmds =("chmod 755 {0}"-f [System.IO.Path]::GetFileName($file)),"$($cmds)","","read -n1 -r -p 'Press any key to continue...' key"
$cmds ="$($cmds)","","read -n1 -r -p 'Press any key to continue...' key"
$cmds|set-content "commands/movefile_to_server.txt" -Encoding Ascii


#------------------------------------------------------
$ssh_key="$PSScriptRoot\ssh-keys/{0}-sshkey.ppk" -f ($acc.cpanel_user)
$url = ("/c {0}/commands/movefile-to-server.bat {1} {2} {3} {4}" -f $PSScriptRoot,$acc.cpanel_host, $acc.cpanel_user,$acc.ssh_key_pass, $ssh_key)
$url
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}
#close $target_accViewer
if(-Not [string]::IsNullOrEmpty($target_accViewer.Id)) {
    Stop-Process -id $target_accViewer.Id
}