<#
#New-SSHSession -ComputerName "216.172.164.142" -Credential (Get-Credential carlos)
#iex (New-Object Net.WebClient).DownloadString("https://gist.github.com/darkoperator/6152630/raw/c67de4f7cd780ba367cccbc2593f38d18ce6df89/instposhsshdev")
New-SSHSession -ComputerName "216.172.164.142" -Credential (Get-Credential root)

#Set-SCPFile -ComputerName "216.172.164.142"  -LocalFile "./yo.mp4" -Credential (Get-Credential "hwvn") -RemotePath "/tmp/yo.mp4"

#New-SFTPSession -ComputerName 216.172.164.142 -Credential (Get-Credential "hwvn") -Verbose | fl

#gcm Set-SCPFile|select-object definition
#>
param([string]$acc_id = "")
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
."..\functions.ps1"

if([string]::IsNullOrEmpty($acc_id)) {
    $acc_id = Read-host "Enter account ID ?"
}
$cpanel_ajax = "http://localhost/cpanel/ajax.php"

## All variables will need changing to suit your environment
connectDB

## get account info
$acc=get_cpanel_info $acc_id
$server_ip = $acc.cpanel_host
$user = $acc.cpanel_user
#valid
if([string]::IsNullOrEmpty($acc.ssh_key_pass)) {
    $acc.ssh_key_pass="X"
}

$acc
#open acc viewer
$accViewer=openAccViewer $acc

$url = ("/c {0}/commands/test-ssh.bat {1} {2} {3} {4}" -f $PSScriptRoot,$server_ip, $user,$acc.ssh_key_pass,"$PSScriptRoot\ssh-keys/$user-sshkey.ppk")
$proc=Start-Process "cmd.exe"  $url -wait

#------------------------------------------------------
#close $accViewer
if(-Not [string]::IsNullOrEmpty($accViewer.Id)) {
    Stop-Process -id $accViewer.Id
}